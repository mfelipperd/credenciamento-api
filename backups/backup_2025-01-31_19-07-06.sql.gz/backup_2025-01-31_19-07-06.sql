-- MySQL dump 10.13  Distrib 8.0.41, for Linux (x86_64)
--
-- Host: mysql    Database: credenciamento_db
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `checkins`
--

DROP TABLE IF EXISTS `checkins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `checkins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `checkInDate` date NOT NULL,
  `createdAt` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `visitorRegistrationCode` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_aedd022288d93469f2790b86fd5` (`visitorRegistrationCode`),
  CONSTRAINT `FK_aedd022288d93469f2790b86fd5` FOREIGN KEY (`visitorRegistrationCode`) REFERENCES `visitors` (`registrationCode`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `checkins`
--

LOCK TABLES `checkins` WRITE;
/*!40000 ALTER TABLE `checkins` DISABLE KEYS */;
INSERT INTO `checkins` VALUES (1,'2025-01-31','2025-01-31 15:51:32.419448','03709ee7-9681-4d40-a76c-7dc6f794acb2'),(2,'2025-01-31','2025-01-31 15:51:45.099203','03709ee7-9681-4d40-a76c-7dc6f794acb2');
/*!40000 ALTER TABLE `checkins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `role` enum('admin','receptionist') NOT NULL,
  `createdAt` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_97672ac88f789774dd47f7c8be` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Maria Silva','maria.silva@example.com','admin','2025-01-30 18:42:05.528103','senhaSegura123');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visitors`
--

DROP TABLE IF EXISTS `visitors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `visitors` (
  `registrationCode` varchar(36) NOT NULL,
  `name` varchar(255) NOT NULL,
  `company` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `cnpj` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `zipCode` varchar(255) NOT NULL,
  `street` varchar(255) DEFAULT NULL,
  `neighborhood` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(2) DEFAULT NULL,
  `sectors` text,
  `category` enum('exhibitor','visitor','retailer','sales_representative') NOT NULL,
  `registrationDate` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `howDidYouKnow` enum('Google','Facebook','Instagram','LinkedIn','Indicação de um amigo','Evento','Jornal','Outro') NOT NULL,
  PRIMARY KEY (`registrationCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visitors`
--

LOCK TABLES `visitors` WRITE;
/*!40000 ALTER TABLE `visitors` DISABLE KEYS */;
INSERT INTO `visitors` VALUES ('03709ee7-9681-4d40-a76c-7dc6f794acb2','João Silva','Tech Solutions','felipperabelodurans2@gmail.com','12345678020199','+5511999979999','12345678','Rua das Flores','Jardim Primavera','São Paulo','SP','Tecnologia','visitor','2025-01-31 13:58:55.357831','Google'),('1f93d153-42bd-45bf-85ff-549eaf1eed5d','João Silva','Tech Solutions','joao.silva@techsolutions.com','12345678000199','+5511999999999','12345678','Rua das Flores','Jardim Primavera','São Paulo','SP','Tecnologia','visitor','2025-01-30 17:57:45.540297','Google'),('2ac3f34f-b1d1-443f-b3d3-6e473f489489','João Silva','Tech Solutions','felipperabelodurans2@gmail.com','12345678020199','+5511999979999','12345678','Rua das Flores','Jardim Primavera','São Paulo','SP','Tecnologia','visitor','2025-01-31 13:37:59.021960','Google'),('2ef504dd-2c8b-4895-81b2-60dc5dc6b2c8','João Silva','Tech Solutions','felipperabelodurans2@gmail.com','12345678020199','+5511999979999','12345678','Rua das Flores','Jardim Primavera','São Paulo','SP','Tecnologia','visitor','2025-01-31 14:03:31.971683','Google'),('38759470-30b1-42fb-8a92-a4737c13ed0a','João Silva','Tech Solutions','felipperabelodurans2@gmail.com','12345678020199','+5511999979999','12345678','Rua das Flores','Jardim Primavera','São Paulo','SP','Tecnologia','visitor','2025-01-31 14:01:42.638642','Google'),('5e10e993-5635-4586-8ec5-a7b33308bd29','João Silva','Tech Solutions','felipperabelodurans2@gmail.com','12345678020199','+5511999979999','12345678','Rua das Flores','Jardim Primavera','São Paulo','SP','Tecnologia','visitor','2025-01-31 13:52:36.614881','Google'),('693ef47e-2850-4b2c-8840-fe357453996e','João Silva','Tech Solutions','felipperabelodurans2@gmail.com','12345678020199','+5511999979999','12345678','Rua das Flores','Jardim Primavera','São Paulo','SP','Tecnologia','visitor','2025-01-31 15:30:38.265933','Google'),('694fcafc-9de5-4fe6-9a87-173fbb4b02c7','João Silva','Tech Solutions','felipperabelodurans2@gmail.com','12345678020199','+5511999979999','12345678','Rua das Flores','Jardim Primavera','São Paulo','SP','Tecnologia','visitor','2025-01-31 13:33:10.050439','Google'),('6d4dabc9-f1db-45f7-abb6-d4609f2ee238','João Silva','Tech Solutions','felipperabelodurans2@gmail.com','12345678020199','+5511999979999','12345678','Rua das Flores','Jardim Primavera','São Paulo','SP','Tecnologia','visitor','2025-01-31 13:56:39.756351','Google'),('8534dd28-103e-4795-9cd7-05b6943cbcb4','João Silva','Tech Solutions','felipperabelodurans2@gmail.com','12345678020199','+5511999979999','12345678','Rua das Flores','Jardim Primavera','São Paulo','SP','Tecnologia','visitor','2025-01-31 14:34:23.321317','Google'),('8fe25269-b2ab-4aca-a198-b7746d7526f8','João Silva','Tech Solutions','felipperabelodurans2@gmail.com','12345678020199','+5511999979999','12345678','Rua das Flores','Jardim Primavera','São Paulo','SP','Tecnologia','visitor','2025-01-31 13:53:34.713484','Google'),('98ccb84d-53c9-46bb-8462-73281c3e0973','João Silva','Tech Solutions','felipperabelodurans2@gmail.com','12345678020199','+5511999979999','12345678','Rua das Flores','Jardim Primavera','São Paulo','SP','Tecnologia','visitor','2025-01-31 14:36:07.963910','Google'),('a01daf9e-0f0b-4fd9-b752-b05d4427b0ca','João Silva','Tech Solutions','felipperabelodurans2@gmail.com','12345678020199','+5511999979999','12345678','Rua das Flores','Jardim Primavera','São Paulo','SP','Tecnologia','visitor','2025-01-31 13:59:49.599968','Google'),('c0b77756-a795-404b-bef6-05ecebbafb31','João Silva','Tech Solutions','felipperabelodurans2@gmail.com','12345678020199','+5511999979999','12345678','Rua das Flores','Jardim Primavera','São Paulo','SP','Tecnologia','visitor','2025-01-31 13:54:42.717844','Google'),('cbf9fa9d-a60b-4e9a-a7be-899459cb4619','João Silva','Tech Solutions','felipperabelodurans2@gmail.com','12345678020199','+5511999979999','12345678','Rua das Flores','Jardim Primavera','São Paulo','SP','Tecnologia','visitor','2025-01-31 13:39:45.927400','Google'),('e86a3b1c-28ae-471f-89fa-ff7d0a2fbab5','João Silva','Tech Solutions','felipperabelodurans2@gmail.com','12345678020199','+5511999979999','12345678','Rua das Flores','Jardim Primavera','São Paulo','SP','Tecnologia','visitor','2025-01-31 15:16:11.307272','Google'),('f4cb654e-2848-4964-ad10-96f1cb399b27','João Silva','Tech Solutions','felipperabelodurans2@gmail.com','12345678020199','+5511999979999','12345678','Rua das Flores','Jardim Primavera','São Paulo','SP','Tecnologia','visitor','2025-01-31 13:56:06.888007','Google'),('f6438b71-2b24-41d4-b6bd-1de460993bd9','João Silva','Tech Solutions','felipperabelodurans2@gmail.com','12345678020199','+5511999979999','12345678','Rua das Flores','Jardim Primavera','São Paulo','SP','Tecnologia','visitor','2025-01-31 14:02:17.742334','Google'),('fad5a28a-806e-49e0-aa02-06be1b4e33ab','João Silva','Tech Solutions','felipperabelodurans2@gmail.com','12345678020199','+5511999979999','12345678','Rua das Flores','Jardim Primavera','São Paulo','SP','Tecnologia','visitor','2025-01-31 13:51:42.971760','Google'),('ffc19ff2-409e-46b3-ade6-5936461c217c','João Silva','Tech Solutions','felipperabelodurans2@gmail.com','12345678020199','+5511999979999','12345678','Rua das Flores','Jardim Primavera','São Paulo','SP','Tecnologia','visitor','2025-01-31 13:52:04.259298','Google');
/*!40000 ALTER TABLE `visitors` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-31 19:07:06
